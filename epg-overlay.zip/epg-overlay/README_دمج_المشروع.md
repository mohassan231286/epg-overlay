# إزاي تدمج الملفات دي في مشروعك

## 1. انسخ الملفات
- انسخ الفولدر `java/com/yourapp/epgoverlay` جوه `app/src/main/java/` بتاع مشروعك
  (غيّر `com.yourapp.epgoverlay` لاسم الباكدج الحقيقي بتاعك في كل ملف .kt)
- انسخ `res/xml/accessibility_service_config.xml`
- انسخ أو ادمج `res/values/strings.xml`
- انسخ `assets/channels.json` و `assets/epg.html`

## 2. عدّل AndroidManifest.xml بتاعك

ضيف الصلاحية دي فوق (خارج `<application>`):
```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
```

وضيف الخدمة دي جوه `<application>`:
```xml
<service
    android:name=".RemoteKeyListenerService"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.accessibilityservice.AccessibilityService" />
    </intent-filter>
    <meta-data
        android:name="android.accessibilityservice.config"
        android:resource="@xml/accessibility_service_config" />
</service>
```

## 3. خطوة الاختبار الأهم (اعملها قبل أي حاجة تانية)

قبل ما تعتمد على `KEYCODE_CHANNEL_UP` / `KEYCODE_CHANNEL_DOWN`، لازم تتأكد
إن ريموتك فعلاً بيبعت الأكواد دي. شغّل الأمر ده وانت متابع:

```
adb logcat -s RemoteKeyListener
```

بعدين دوس زرار تغيير القناة (فوق/تحت) في الريموت الفيزيقي. هيطلعلك سطر
زي كده:
```
Key received: action=0 keyCode=166 (KEYCODE_CHANNEL_UP)
```

- لو طلع `KEYCODE_CHANNEL_UP` / `KEYCODE_CHANNEL_DOWN` → الكود جاهز عادي، مش محتاج تعديل.
- لو طلع كود تاني (زي `KEYCODE_DPAD_UP` مثلًا) → افتح
  `RemoteKeyListenerService.kt` وشيل التعليق عن السطرين المعلّقين
  اللي بيتعاملوا مع DPAD، أو ضيف الكود اللي ظهر فعليًا.

## 4. خطوات التشغيل على الجهاز

1. ثبّت الـ APK
2. افتح التطبيق - هيطلب صلاحية "الرسم فوق التطبيقات" (Draw over other apps) → وافق
3. هيوجّهك لشاشة Accessibility → لاقي اسم التطبيق وفعّله يدويًا
4. ارجع لجلايد وجرب تغيّر قناة بالريموت - هيبان الـ Infobar فوق الفيديو تلقائيًا

## 5. الخطوة الجاية (لما تكون جاهز)

- استبدل `channels.json` بقائمة قنواتك الحقيقية (لازم الأرقام تتطابق 100%
  مع ترتيب جلايد، زي ما أكدت)
- لو عايز تربط EPG حقيقي (اسم البرنامج الحالي + نسبة التقدّم)، فيه دالة
  جاهزة في `epg.html` اسمها `onProgramInfo(name, percent)` تقدر تنادها من
  `OverlayManager.kt` بعد ما تجيب بيانات EPG من مصدرك (XMLTV أو غيره)

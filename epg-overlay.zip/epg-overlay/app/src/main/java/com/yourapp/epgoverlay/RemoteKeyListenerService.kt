package com.yourapp.epgoverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * الخدمة دي بتسمع كل ضغطات الريموت في السيستم كله (حتى وهي رايحة لجلايد)
 * من غير ما توقفها - onKeyEvent بترجع false دايمًا يعني "خليها تكمل مسيرها".
 *
 * لازم اليوزر يفعّلها يدويًا من:
 * Settings -> Accessibility -> Apps -> EPG Overlay -> تشغيل
 *
 * ملحوظة مهمة: مش كل الريموتات بتبعت KEYCODE_CHANNEL_UP/DOWN فعليًا،
 * بعضها بيبعت DPAD_UP/DOWN أو حتى Custom keycode.
 * أول حاجة تعملها: شغّل logcat وشوف الأكواد الحقيقية اللي بتوصل
 * (راجع تعليق "خطوة الاختبار" تحت).
 */
class RemoteKeyListenerService : AccessibilityService() {

    companion object {
        private const val TAG = "RemoteKeyListener"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = AccessibilityServiceInfo().apply {
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        }

        ChannelState.loadChannels(applicationContext)
        OverlayManager.attach(applicationContext)

        Log.d(TAG, "الخدمة اشتغلت وبتسمع للريموت دلوقتي")
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // ============ خطوة الاختبار (مهم تعملها الأول) ============
        // شيل التعليق عن السطر ده وشغّل: adb logcat -s RemoteKeyListener
        // ودوس أزرار تغيير القناة في الريموت وشوف الأكواد اللي بتظهر
        Log.d(TAG, "Key received: action=${event.action} keyCode=${event.keyCode} (${KeyEvent.keyCodeToString(event.keyCode)})")

        if (event.action != KeyEvent.ACTION_DOWN) return false

        when (event.keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP -> ChannelState.moveNext()
            KeyEvent.KEYCODE_CHANNEL_DOWN -> ChannelState.movePrev()

            // شيل التعليق عن السطرين دول لو logcat وريك إن الريموت
            // بيبعت DPAD بدل CHANNEL_UP/DOWN
            // KeyEvent.KEYCODE_DPAD_UP -> ChannelState.moveNext()
            // KeyEvent.KEYCODE_DPAD_DOWN -> ChannelState.movePrev()

            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 ->
                ChannelState.appendDigit(event.keyCode - KeyEvent.KEYCODE_0)
        }

        // مهم جدًا: false يعني "الزرار يكمل مسيره لجلايد عادي"
        // لو رجعت true هتوقف الزرار عن جلايد خالص وهيبقى تحكم كامل بدل مراقبة
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // مش محتاجينه دلوقتي، بس سايبينه لو احتجت لاحقًا تقرأ حاجة من الشاشة
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        OverlayManager.detach()
    }
}

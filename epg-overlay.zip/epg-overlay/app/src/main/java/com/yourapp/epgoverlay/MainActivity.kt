package com.yourapp.epgoverlay

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * شاشة إعداد بسيطة: بتتأكد إن صلاحية "الرسم فوق التطبيقات" شغالة،
 * وبتوجّه اليوزر يفعّل خدمة الـ Accessibility يدويًا (لازم تفعيل يدوي،
 * أندرويد مش بيسمح تفعيلها برمجيًا لأسباب أمنية).
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "محتاج تسمح بالرسم فوق التطبيقات الأول", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        Toast.makeText(
            this,
            "دلوقتي فعّل الخدمة من قايمة Accessibility اللي هتفتح",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

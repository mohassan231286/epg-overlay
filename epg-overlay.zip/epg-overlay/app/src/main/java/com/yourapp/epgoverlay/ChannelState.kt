package com.yourapp.epgoverlay

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import org.json.JSONArray

data class Channel(
    val number: Int,
    val name: String,
    val logoUrl: String? = null
)

/**
 * ده مصدر الحقيقة الوحيد لرقم القناة الحالي.
 * مش بيقرأ من جلايد خالص - بيحسب بنفسه بناءً على ضغطات الريموت
 * اللي بتوصله من RemoteKeyListenerService، وبيتبع نفس منطق
 * الإنيجما في إدخال الأرقام (كتابة رقم -> انتظار -> تنفيذ).
 */
object ChannelState {

    private const val TAG = "ChannelState"

    private val channels = mutableListOf<Channel>()
    private var currentIndex = 0
    private val digitBuffer = StringBuilder()
    private var digitJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    interface Listener {
        fun onChannelChanged(channel: Channel)
        fun onDigitEntry(partialNumber: String)
    }

    private var listener: Listener? = null

    fun setListener(l: Listener?) {
        listener = l
    }

    /** حمّل قائمة القنوات من assets/channels.json (لازم تتطابق مع ترتيب جلايد) */
    fun loadChannels(context: Context, assetFileName: String = "channels.json") {
        channels.clear()
        try {
            val json = context.assets.open(assetFileName).bufferedReader().use { it.readText() }
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                channels.add(
                    Channel(
                        number = obj.getInt("number"),
                        name = obj.getString("name"),
                        logoUrl = obj.optString("logo").ifBlank { null }
                    )
                )
            }
            channels.sortBy { it.number }
            currentIndex = 0
            Log.d(TAG, "تم تحميل ${channels.size} قناة")
        } catch (e: Exception) {
            Log.e(TAG, "فشل تحميل channels.json: ${e.message}")
        }
    }

    fun current(): Channel? = channels.getOrNull(currentIndex)

    fun moveNext() {
        if (channels.isEmpty()) return
        currentIndex = (currentIndex + 1) % channels.size
        emitChange()
    }

    fun movePrev() {
        if (channels.isEmpty()) return
        currentIndex = (currentIndex - 1 + channels.size) % channels.size
        emitChange()
    }

    /**
     * إدخال رقم القناة رقم-رقم زي الإنيجما بالظبط:
     * كل رقم بيتاخد، وبينتظر 1.8 ثانية للرقم اللي بعده،
     * لو محدش دخل بينفذ القفزة للقناة اللي اترقمت.
     */
    fun appendDigit(d: Int) {
        digitBuffer.append(d)
        listener?.onDigitEntry(digitBuffer.toString())

        digitJob?.cancel()
        digitJob = scope.launch {
            delay(1800)
            commitDigitEntry()
        }

        // لو وصل لـ 3 خانات (أقصى رقم قناة متوقع) نفّذ فورًا من غير انتظار
        if (digitBuffer.length >= 3) {
            digitJob?.cancel()
            commitDigitEntry()
        }
    }

    private fun commitDigitEntry() {
        val requested = digitBuffer.toString().toIntOrNull()
        digitBuffer.clear()
        if (requested != null) {
            val idx = channels.indexOfFirst { it.number == requested }
            if (idx >= 0) {
                currentIndex = idx
                emitChange()
            } else {
                Log.w(TAG, "رقم قناة $requested مش موجود في القائمة")
            }
        }
    }

    fun setCurrentByNumber(number: Int) {
        val idx = channels.indexOfFirst { it.number == number }
        if (idx >= 0) {
            currentIndex = idx
            emitChange()
        }
    }

    fun allChannels(): List<Channel> = channels.toList()

    private fun emitChange() {
        current()?.let {
            Log.d(TAG, "القناة الحالية: ${it.number} - ${it.name}")
            listener?.onChannelChanged(it)
        }
    }
}

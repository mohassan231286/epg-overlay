package com.yourapp.epgoverlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

/**
 * بيرسم WebView شفاف فوق كل حاجة (حتى فوق جلايد وهو شغال فيديو)
 * من غير ما ياخد اللمس أو الفوكس، فجلايد فاضل يستقبل الريموت عادي.
 */
object OverlayManager : ChannelState.Listener {

    private const val TAG = "OverlayManager"

    private var windowManager: WindowManager? = null
    private var webView: WebView? = null
    private var attached = false

    @SuppressLint("SetJavaScriptEnabled")
    fun attach(context: Context) {
        if (attached) return

        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        webView = WebView(context).apply {
            setBackgroundColor(0) // شفاف تمامًا
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(JsBridge(), "Native")
            loadUrl("file:///android_asset/epg.html")
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager?.addView(webView, params)
            attached = true
            ChannelState.setListener(this)
            Log.d(TAG, "الـ Overlay اتحط فوق الشاشة بنجاح")
        } catch (e: Exception) {
            // لو ده حصل، غالبًا صلاحية "Draw over other apps" مش متفعّلة
            Log.e(TAG, "فشل عرض الـ Overlay: ${e.message}")
        }
    }

    fun detach() {
        webView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        webView = null
        attached = false
        ChannelState.setListener(null)
    }

    override fun onChannelChanged(channel: Channel) {
        val json = JSONObject().apply {
            put("number", channel.number)
            put("name", channel.name)
            put("logo", channel.logoUrl ?: "")
        }
        webView?.post {
            webView?.evaluateJavascript(
                "window.onChannelChanged && window.onChannelChanged($json)", null
            )
        }
    }

    override fun onDigitEntry(partialNumber: String) {
        webView?.post {
            webView?.evaluateJavascript(
                "window.onDigitEntry && window.onDigitEntry('$partialNumber')", null
            )
        }
    }

    /** جسر إضافي لو الـ HTML احتاج يطلب بيانات من الكوتلن (مش إجباري تستخدمه) */
    class JsBridge {
        @JavascriptInterface
        fun requestChannelList(): String {
            val arr = ChannelState.allChannels().map {
                mapOf("number" to it.number, "name" to it.name, "logo" to (it.logoUrl ?: ""))
            }
            return org.json.JSONArray(arr).toString()
        }
    }
}
